import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const journalists = pgTable("journalists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  outlet: text("outlet").notNull(),
  beat: text("beat").notNull(),
  location: text("location"),
  bio: text("bio"),
  articleCount: integer("article_count").notNull().default(0),
  influenceScore: integer("influence_score").notNull().default(0),
  avatarUrl: text("avatar_url"),
});

export const articles = pgTable("articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  journalistId: varchar("journalist_id").notNull(),
  outlet: text("outlet").notNull(),
  publishedAt: timestamp("published_at").notNull(),
  url: text("url").notNull(),
  excerpt: text("excerpt"),
  topics: text("topics").array().notNull().default(sql`ARRAY[]::text[]`),
});

export const outlets = pgTable("outlets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  journalistCount: integer("journalist_count").notNull().default(0),
  articleFrequency: integer("article_frequency").notNull().default(0),
  logoUrl: text("logo_url"),
});

export const insertJournalistSchema = createInsertSchema(journalists).omit({
  id: true,
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
});

export const insertOutletSchema = createInsertSchema(outlets).omit({
  id: true,
});

export type InsertJournalist = z.infer<typeof insertJournalistSchema>;
export type Journalist = typeof journalists.$inferSelect;

export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type Article = typeof articles.$inferSelect;

export type InsertOutlet = z.infer<typeof insertOutletSchema>;
export type Outlet = typeof outlets.$inferSelect;
