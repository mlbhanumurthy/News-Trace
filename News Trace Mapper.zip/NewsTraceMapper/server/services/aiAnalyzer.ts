import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface JournalistAnalysis {
  name: string;
  outlet: string;
  beat: string;
  expertise: string[];
  writingStyle: string;
  influenceScore: number;
}

export async function analyzeJournalistFromArticle(
  articleTitle: string,
  articleContent: string,
  author: string
): Promise<JournalistAnalysis | null> {
  try {
    const prompt = `Analyze this news article and provide structured information about the journalist:

Article Title: ${articleTitle}
Author: ${author}
Content: ${articleContent.slice(0, 1000)}

Based on this article, provide:
1. The journalist's primary beat/topic area (e.g., Technology, Politics, Business)
2. Areas of expertise (3-5 specific topics they cover)
3. Writing style description (brief, one sentence)
4. Estimated influence score (0-100) based on depth of coverage and outlet

Respond in JSON format:
{
  "beat": "string",
  "expertise": ["string"],
  "writingStyle": "string",
  "influenceScore": number
}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are an expert media analyst who evaluates journalists and their coverage patterns. Respond only with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 300,
    });

    const responseText = completion.choices[0]?.message?.content;
    if (!responseText) return null;

    const analysis = JSON.parse(responseText);
    
    return {
      name: author,
      outlet: extractOutletFromAuthor(author),
      beat: analysis.beat || "General",
      expertise: analysis.expertise || [],
      writingStyle: analysis.writingStyle || "",
      influenceScore: Math.min(100, Math.max(0, analysis.influenceScore || 50)),
    };
  } catch (error) {
    console.error('Error analyzing journalist:', error);
    return null;
  }
}

export async function extractTopicsFromArticle(articleTitle: string, articleContent: string): Promise<string[]> {
  try {
    const prompt = `Extract 3-5 main topics from this article:

Title: ${articleTitle}
Content: ${articleContent.slice(0, 800)}

Return only a JSON array of topic strings, like: ["topic1", "topic2", "topic3"]`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You extract key topics from news articles. Respond only with a JSON array of strings."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 100,
    });

    const responseText = completion.choices[0]?.message?.content;
    if (!responseText) return [];

    const topics = JSON.parse(responseText);
    return Array.isArray(topics) ? topics : [];
  } catch (error) {
    console.error('Error extracting topics:', error);
    return [];
  }
}

function extractOutletFromAuthor(author: string): string {
  const parts = author.split(/[@,]/);
  if (parts.length > 1) {
    return parts[1].trim();
  }
  return "Unknown";
}
