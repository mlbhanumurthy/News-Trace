import Parser from "rss-parser";
import { storage } from "../storage";

const parser = new Parser({
  customFields: {
    item: [
      ['dc:creator', 'author'],
      ['media:content', 'mediaContent'],
    ],
  },
});

export interface ParsedArticle {
  title: string;
  link: string;
  pubDate: string;
  author?: string;
  content?: string;
  contentSnippet?: string;
  guid?: string;
}

export async function parseRSSFeed(feedUrl: string): Promise<ParsedArticle[]> {
  try {
    const feed = await parser.parseURL(feedUrl);
    
    return feed.items.map(item => ({
      title: item.title || '',
      link: item.link || '',
      pubDate: item.pubDate || new Date().toISOString(),
      author: (item as any).author || item.creator,
      content: item.content,
      contentSnippet: item.contentSnippet,
      guid: item.guid,
    }));
  } catch (error) {
    console.error('Error parsing RSS feed:', error);
    return [];
  }
}

export const DEFAULT_FEEDS = [
  'https://feeds.arstechnica.com/arstechnica/index',
  'https://www.theguardian.com/world/rss',
  'https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml',
  'https://www.wired.com/feed/rss',
];

export async function ingestArticlesFromFeeds() {
  console.log('Starting RSS feed ingestion...');
  
  for (const feedUrl of DEFAULT_FEEDS) {
    try {
      const articles = await parseRSSFeed(feedUrl);
      console.log(`Parsed ${articles.length} articles from ${feedUrl}`);
      
      for (const article of articles.slice(0, 3)) {
        if (!article.author) continue;
        
        const outlet = extractOutletFromUrl(article.link);
        
        const existingOutlets = await storage.getAllOutlets();
        let outletRecord = existingOutlets.find(o => o.name.toLowerCase() === outlet.toLowerCase());
        
        if (!outletRecord) {
          outletRecord = await storage.createOutlet({
            name: outlet,
            category: "News",
            journalistCount: 0,
            articleFrequency: 0,
          });
        }
        
        const existingJournalists = await storage.getAllJournalists();
        const authorName = article.author!;
        let journalistRecord = existingJournalists.find(j => 
          j.name.toLowerCase() === authorName.toLowerCase() && 
          j.outlet.toLowerCase() === outlet.toLowerCase()
        );
        
        if (!journalistRecord) {
          journalistRecord = await storage.createJournalist({
            name: authorName,
            outlet,
            beat: "General",
            articleCount: 1,
            influenceScore: 50,
          });
        }
        
        await storage.createArticle({
          title: article.title,
          journalistId: journalistRecord.id,
          outlet,
          publishedAt: new Date(article.pubDate),
          url: article.link,
          excerpt: article.contentSnippet?.slice(0, 200) || null,
          topics: [],
        });
        
        await storage.updateJournalistArticleCount(journalistRecord.id, journalistRecord.articleCount + 1);
      }
    } catch (error) {
      console.error(`Error ingesting from ${feedUrl}:`, error);
    }
  }
  
  console.log('RSS feed ingestion complete');
}

function extractOutletFromUrl(url: string): string {
  try {
    const hostname = new URL(url).hostname;
    const parts = hostname.split('.');
    const domain = parts.length > 2 ? parts[parts.length - 2] : parts[0];
    return domain.charAt(0).toUpperCase() + domain.slice(1);
  } catch {
    return 'Unknown';
  }
}
