import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { parseRSSFeed, ingestArticlesFromFeeds, DEFAULT_FEEDS } from "./services/rssParser";
import { analyzeJournalistFromArticle, extractTopicsFromArticle } from "./services/aiAnalyzer";
import { insertJournalistSchema, insertArticleSchema, insertOutletSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Journalist routes
  app.get("/api/journalists", async (_req, res) => {
    try {
      const journalists = await storage.getAllJournalists();
      res.json(journalists);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch journalists" });
    }
  });

  app.get("/api/journalists/:id", async (req, res) => {
    try {
      const journalist = await storage.getJournalist(req.params.id);
      if (!journalist) {
        return res.status(404).json({ error: "Journalist not found" });
      }
      res.json(journalist);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch journalist" });
    }
  });

  app.post("/api/journalists", async (req, res) => {
    try {
      const validatedData = insertJournalistSchema.parse(req.body);
      const journalist = await storage.createJournalist(validatedData);
      res.status(201).json(journalist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create journalist" });
    }
  });

  // Outlet routes
  app.get("/api/outlets", async (_req, res) => {
    try {
      const outlets = await storage.getAllOutlets();
      res.json(outlets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch outlets" });
    }
  });

  app.get("/api/outlets/:id", async (req, res) => {
    try {
      const outlet = await storage.getOutlet(req.params.id);
      if (!outlet) {
        return res.status(404).json({ error: "Outlet not found" });
      }
      res.json(outlet);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch outlet" });
    }
  });

  app.post("/api/outlets", async (req, res) => {
    try {
      const validatedData = insertOutletSchema.parse(req.body);
      const outlet = await storage.createOutlet(validatedData);
      res.status(201).json(outlet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create outlet" });
    }
  });

  // Article routes
  app.get("/api/articles", async (_req, res) => {
    try {
      const articles = await storage.getAllArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch articles" });
    }
  });

  app.get("/api/articles/:id", async (req, res) => {
    try {
      const article = await storage.getArticle(req.params.id);
      if (!article) {
        return res.status(404).json({ error: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch article" });
    }
  });

  app.post("/api/articles", async (req, res) => {
    try {
      const validatedData = insertArticleSchema.parse(req.body);
      const article = await storage.createArticle(validatedData);
      res.status(201).json(article);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create article" });
    }
  });

  // RSS and AI-powered analysis routes
  app.post("/api/ingest/rss", async (req, res) => {
    try {
      const { feedUrl } = req.body;
      
      if (!feedUrl) {
        return res.status(400).json({ error: "feedUrl is required" });
      }

      const articles = await parseRSSFeed(feedUrl);
      res.json({ success: true, articlesFound: articles.length, articles });
    } catch (error) {
      res.status(500).json({ error: "Failed to parse RSS feed" });
    }
  });

  app.post("/api/ingest/analyze", async (req, res) => {
    try {
      await ingestArticlesFromFeeds();
      res.json({ success: true, message: "Articles ingested from default feeds" });
    } catch (error) {
      res.status(500).json({ error: "Failed to ingest articles" });
    }
  });

  app.post("/api/analyze/journalist", async (req, res) => {
    try {
      const { articleTitle, articleContent, author } = req.body;
      
      if (!articleTitle || !articleContent || !author) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const analysis = await analyzeJournalistFromArticle(articleTitle, articleContent, author);
      
      if (!analysis) {
        return res.status(500).json({ error: "Failed to analyze journalist" });
      }

      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to analyze journalist" });
    }
  });

  app.post("/api/analyze/topics", async (req, res) => {
    try {
      const { articleTitle, articleContent } = req.body;
      
      if (!articleTitle || !articleContent) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const topics = await extractTopicsFromArticle(articleTitle, articleContent);
      res.json({ topics });
    } catch (error) {
      res.status(500).json({ error: "Failed to extract topics" });
    }
  });

  // Stats endpoint
  app.get("/api/stats", async (_req, res) => {
    try {
      const journalists = await storage.getAllJournalists();
      const outlets = await storage.getAllOutlets();
      const articles = await storage.getAllArticles();

      res.json({
        journalistCount: journalists.length,
        outletCount: outlets.length,
        articleCount: articles.length,
        avgInfluenceScore: journalists.length > 0
          ? Math.round(journalists.reduce((sum, j) => sum + j.influenceScore, 0) / journalists.length)
          : 0,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
