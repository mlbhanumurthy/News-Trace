import { type Journalist, type InsertJournalist, type Outlet, type InsertOutlet, type Article, type InsertArticle } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getJournalist(id: string): Promise<Journalist | undefined>;
  getAllJournalists(): Promise<Journalist[]>;
  createJournalist(journalist: InsertJournalist): Promise<Journalist>;
  updateJournalistArticleCount(id: string, count: number): Promise<void>;
  
  getOutlet(id: string): Promise<Outlet | undefined>;
  getAllOutlets(): Promise<Outlet[]>;
  createOutlet(outlet: InsertOutlet): Promise<Outlet>;
  
  getArticle(id: string): Promise<Article | undefined>;
  getAllArticles(): Promise<Article[]>;
  createArticle(article: InsertArticle): Promise<Article>;
}

export class MemStorage implements IStorage {
  private journalists: Map<string, Journalist>;
  private outlets: Map<string, Outlet>;
  private articles: Map<string, Article>;

  constructor() {
    this.journalists = new Map();
    this.outlets = new Map();
    this.articles = new Map();
  }

  async getJournalist(id: string): Promise<Journalist | undefined> {
    return this.journalists.get(id);
  }

  async getAllJournalists(): Promise<Journalist[]> {
    return Array.from(this.journalists.values());
  }

  async createJournalist(insertJournalist: InsertJournalist): Promise<Journalist> {
    const id = randomUUID();
    const journalist: Journalist = { 
      id,
      name: insertJournalist.name,
      outlet: insertJournalist.outlet,
      beat: insertJournalist.beat,
      location: insertJournalist.location ?? null,
      bio: insertJournalist.bio ?? null,
      articleCount: insertJournalist.articleCount ?? 0,
      influenceScore: insertJournalist.influenceScore ?? 0,
      avatarUrl: insertJournalist.avatarUrl ?? null,
    };
    this.journalists.set(id, journalist);
    return journalist;
  }

  async updateJournalistArticleCount(id: string, count: number): Promise<void> {
    const journalist = this.journalists.get(id);
    if (journalist) {
      journalist.articleCount = count;
      this.journalists.set(id, journalist);
    }
  }

  async getOutlet(id: string): Promise<Outlet | undefined> {
    return this.outlets.get(id);
  }

  async getAllOutlets(): Promise<Outlet[]> {
    return Array.from(this.outlets.values());
  }

  async createOutlet(insertOutlet: InsertOutlet): Promise<Outlet> {
    const id = randomUUID();
    const outlet: Outlet = { 
      id,
      name: insertOutlet.name,
      category: insertOutlet.category,
      journalistCount: insertOutlet.journalistCount ?? 0,
      articleFrequency: insertOutlet.articleFrequency ?? 0,
      logoUrl: insertOutlet.logoUrl ?? null,
    };
    this.outlets.set(id, outlet);
    return outlet;
  }

  async getArticle(id: string): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async getAllArticles(): Promise<Article[]> {
    return Array.from(this.articles.values());
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = randomUUID();
    const article: Article = { 
      id,
      title: insertArticle.title,
      journalistId: insertArticle.journalistId,
      outlet: insertArticle.outlet,
      publishedAt: insertArticle.publishedAt,
      url: insertArticle.url,
      excerpt: insertArticle.excerpt ?? null,
      topics: insertArticle.topics ?? [],
    };
    this.articles.set(id, article);
    return article;
  }
}

export const storage = new MemStorage();
