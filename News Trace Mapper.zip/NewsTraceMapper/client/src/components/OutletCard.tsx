import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, FileText } from "lucide-react";

interface OutletCardProps {
  id: string;
  name: string;
  category: string;
  journalistCount: number;
  articleFrequency: number;
}

export function OutletCard({
  id,
  name,
  category,
  journalistCount,
  articleFrequency,
}: OutletCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-outlet-${id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-muted">
              <Building2 className="h-6 w-6 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <CardTitle className="text-lg truncate" data-testid={`text-outlet-name-${id}`}>{name}</CardTitle>
              <Badge variant="outline" className="mt-1">
                {category}
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>Journalists</span>
          </div>
          <span className="font-medium">{journalistCount}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <FileText className="h-4 w-4" />
            <span>Articles/Month</span>
          </div>
          <span className="font-medium">{articleFrequency}</span>
        </div>
      </CardContent>
    </Card>
  );
}
