import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, UserPlus, TrendingUp } from "lucide-react";

interface JournalistCardProps {
  id: string;
  name: string;
  outlet: string;
  beat: string;
  articleCount: number;
  influenceScore: number;
  avatarUrl?: string | null;
  onViewProfile?: (id: string) => void;
  onTrack?: (id: string) => void;
}

export function JournalistCard({
  id,
  name,
  outlet,
  beat,
  articleCount,
  influenceScore,
  avatarUrl,
  onViewProfile,
  onTrack,
}: JournalistCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="hover-elevate" data-testid={`card-journalist-${id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src={avatarUrl || undefined} alt={name} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate" data-testid={`text-journalist-name-${id}`}>{name}</h3>
            <p className="text-sm text-muted-foreground truncate">{outlet}</p>
            <Badge variant="secondary" className="mt-2">
              {beat}
            </Badge>
          </div>
        </div>
        <div className="mt-4 flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Articles:</span>
            <span className="font-medium">{articleCount}</span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3 text-chart-1" />
            <span className="font-medium">{influenceScore}</span>
          </div>
        </div>
        <div className="mt-4 flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="flex-1"
            onClick={() => onViewProfile?.(id)}
            data-testid={`button-view-${id}`}
          >
            <Eye className="h-4 w-4 mr-1" />
            View
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="flex-1"
            onClick={() => onTrack?.(id)}
            data-testid={`button-track-${id}`}
          >
            <UserPlus className="h-4 w-4 mr-1" />
            Track
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
