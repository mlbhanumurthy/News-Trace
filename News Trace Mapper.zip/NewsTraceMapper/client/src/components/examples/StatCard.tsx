import { StatCard } from "../StatCard";
import { Users } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="p-4">
      <StatCard
        title="Total Journalists"
        value="2,847"
        change="+12.5% from last month"
        changeType="positive"
        icon={Users}
      />
    </div>
  );
}
