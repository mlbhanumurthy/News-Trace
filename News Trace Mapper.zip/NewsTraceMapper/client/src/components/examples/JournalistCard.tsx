import { JournalistCard } from "../JournalistCard";

export default function JournalistCardExample() {
  return (
    <div className="p-4 max-w-sm">
      <JournalistCard
        id="1"
        name="Sarah Chen"
        outlet="TechCrunch"
        beat="AI & Machine Learning"
        articleCount={156}
        influenceScore={92}
        onViewProfile={(id) => console.log("View profile:", id)}
        onTrack={(id) => console.log("Track journalist:", id)}
      />
    </div>
  );
}
