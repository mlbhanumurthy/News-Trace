import { NetworkGraph } from "../NetworkGraph";

export default function NetworkGraphExample() {
  return (
    <div className="p-4">
      <NetworkGraph />
    </div>
  );
}
