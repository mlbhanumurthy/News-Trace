import { TopicDistribution } from "../TopicDistribution";

export default function TopicDistributionExample() {
  return (
    <div className="p-4">
      <TopicDistribution />
    </div>
  );
}
