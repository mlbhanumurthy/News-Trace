import { OutletCard } from "../OutletCard";

export default function OutletCardExample() {
  return (
    <div className="p-4 max-w-sm">
      <OutletCard
        id="1"
        name="TechCrunch"
        category="Technology"
        journalistCount={87}
        articleFrequency={342}
      />
    </div>
  );
}
