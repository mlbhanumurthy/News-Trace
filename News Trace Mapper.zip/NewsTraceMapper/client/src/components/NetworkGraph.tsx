import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, Maximize2, Download } from "lucide-react";

export function NetworkGraph() {
  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <CardTitle>Journalist Network</CardTitle>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => console.log("Zoom in")}
              data-testid="button-zoom-in"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => console.log("Zoom out")}
              data-testid="button-zoom-out"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => console.log("Fullscreen")}
              data-testid="button-fullscreen"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => console.log("Export")}
              data-testid="button-export"
            >
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="relative h-[600px] bg-gradient-to-br from-background to-muted/20">
          <svg className="w-full h-full">
            <defs>
              <radialGradient id="node-gradient-1" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity="0.8" />
                <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity="0.2" />
              </radialGradient>
              <radialGradient id="node-gradient-2" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="hsl(var(--chart-2))" stopOpacity="0.8" />
                <stop offset="100%" stopColor="hsl(var(--chart-2))" stopOpacity="0.2" />
              </radialGradient>
            </defs>
            
            <line x1="200" y1="300" x2="400" y2="200" stroke="hsl(var(--border))" strokeWidth="2" opacity="0.3" />
            <line x1="400" y1="200" x2="600" y2="300" stroke="hsl(var(--border))" strokeWidth="2" opacity="0.3" />
            <line x1="200" y1="300" x2="600" y2="300" stroke="hsl(var(--border))" strokeWidth="1" opacity="0.2" />
            <line x1="400" y1="200" x2="400" y2="400" stroke="hsl(var(--border))" strokeWidth="2" opacity="0.3" />
            <line x1="600" y1="300" x2="400" y2="400" stroke="hsl(var(--border))" strokeWidth="2" opacity="0.3" />
            <line x1="200" y1="300" x2="400" y2="400" stroke="hsl(var(--border))" strokeWidth="1" opacity="0.2" />
            
            <circle cx="200" cy="300" r="30" fill="url(#node-gradient-1)" className="hover-elevate cursor-pointer" />
            <circle cx="400" cy="200" r="40" fill="url(#node-gradient-1)" className="hover-elevate cursor-pointer" />
            <circle cx="600" cy="300" r="25" fill="url(#node-gradient-2)" className="hover-elevate cursor-pointer" />
            <circle cx="400" cy="400" r="35" fill="url(#node-gradient-2)" className="hover-elevate cursor-pointer" />
            
            <text x="200" y="305" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12" fontWeight="500">Tech</text>
            <text x="400" y="205" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12" fontWeight="500">Politics</text>
            <text x="600" y="305" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12" fontWeight="500">Sports</text>
            <text x="400" y="405" textAnchor="middle" fill="hsl(var(--foreground))" fontSize="12" fontWeight="500">Business</text>
          </svg>
          <div className="absolute bottom-4 left-4 p-3 bg-card/80 backdrop-blur-sm border rounded-md">
            <div className="text-xs space-y-1">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-chart-1"></div>
                <span>Tier 1 Outlets</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-chart-2"></div>
                <span>Regional Outlets</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
