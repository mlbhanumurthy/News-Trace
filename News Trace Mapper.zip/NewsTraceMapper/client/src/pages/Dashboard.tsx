import { useQuery } from "@tanstack/react-query";
import { Users, Building2, FileText, TrendingUp } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { JournalistCard } from "@/components/JournalistCard";
import { NetworkGraph } from "@/components/NetworkGraph";
import { ActivityChart } from "@/components/ActivityChart";
import { TopicDistribution } from "@/components/TopicDistribution";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Journalist } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: stats } = useQuery<{
    journalistCount: number;
    outletCount: number;
    articleCount: number;
    avgInfluenceScore: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const { data: journalists = [], isLoading } = useQuery<Journalist[]>({
    queryKey: ["/api/journalists"],
  });

  const handleIngestArticles = async () => {
    try {
      toast({
        title: "Starting ingestion...",
        description: "Analyzing articles from RSS feeds",
      });

      const response = await fetch("/api/ingest/analyze", {
        method: "POST",
      });
      
      if (!response.ok) throw new Error("Failed to ingest");

      toast({
        title: "Success!",
        description: "Articles ingested and analyzed",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to ingest articles",
        variant: "destructive",
      });
    }
  };

  const topJournalists = journalists
    .sort((a, b) => b.influenceScore - a.influenceScore)
    .slice(0, 4);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Real-time intelligence across the media ecosystem
          </p>
        </div>
        <Button onClick={handleIngestArticles} data-testid="button-ingest">
          Analyze Latest Articles
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Journalists"
          value={stats?.journalistCount || 0}
          change="+12.5% from last month"
          changeType="positive"
          icon={Users}
        />
        <StatCard
          title="Media Outlets"
          value={stats?.outletCount || 0}
          change="+3 new this week"
          changeType="positive"
          icon={Building2}
        />
        <StatCard
          title="Articles Tracked"
          value={stats?.articleCount || 0}
          change="+8.2% from last month"
          changeType="positive"
          icon={FileText}
        />
        <StatCard
          title="Avg. Influence Score"
          value={stats?.avgInfluenceScore || 0}
          change="+2.1 points"
          changeType="positive"
          icon={TrendingUp}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <ActivityChart />
        <TopicDistribution />
      </div>

      <div>
        <h2 className="text-2xl font-semibold tracking-tight mb-4">
          Top Journalists
        </h2>
        {isLoading ? (
          <div className="text-muted-foreground">Loading journalists...</div>
        ) : topJournalists.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {topJournalists.map((journalist) => (
              <JournalistCard
                key={journalist.id}
                {...journalist}
                onViewProfile={(id) => console.log("View profile:", id)}
                onTrack={(id) => console.log("Track journalist:", id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No journalists yet. Click "Analyze Latest Articles" to start ingesting data.
          </div>
        )}
      </div>

      <NetworkGraph />
    </div>
  );
}
