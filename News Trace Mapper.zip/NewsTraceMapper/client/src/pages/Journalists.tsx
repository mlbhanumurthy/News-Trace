import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { JournalistCard } from "@/components/JournalistCard";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter, SlidersHorizontal } from "lucide-react";
import type { Journalist } from "@shared/schema";

const beats = ["All", "Politics", "Technology", "Finance", "Environment", "Health"];

export default function Journalists() {
  const [selectedBeat, setSelectedBeat] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: journalists = [], isLoading } = useQuery<Journalist[]>({
    queryKey: ["/api/journalists"],
  });

  const filteredJournalists = journalists.filter((j) => {
    const matchesBeat = selectedBeat === "All" || j.beat.toLowerCase().includes(selectedBeat.toLowerCase());
    const matchesSearch = !searchQuery || 
      j.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.outlet.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.beat.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesBeat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">Journalists</h1>
        <p className="text-muted-foreground mt-2">
          Discover and track journalists across {journalists.length}+ profiles
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <SearchBar onSearch={setSearchQuery} />
        <Button variant="outline" data-testid="button-filters">
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
        <Button variant="outline" data-testid="button-sort">
          <SlidersHorizontal className="h-4 w-4 mr-2" />
          Sort
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {beats.map((beat) => (
          <Badge
            key={beat}
            variant={selectedBeat === beat ? "default" : "outline"}
            className="cursor-pointer hover-elevate active-elevate-2"
            onClick={() => setSelectedBeat(beat)}
            data-testid={`badge-beat-${beat.toLowerCase()}`}
          >
            {beat}
          </Badge>
        ))}
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading journalists...</div>
      ) : filteredJournalists.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredJournalists.map((journalist) => (
            <JournalistCard
              key={journalist.id}
              {...journalist}
              onViewProfile={(id) => console.log("View profile:", id)}
              onTrack={(id) => console.log("Track journalist:", id)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          No journalists found matching your criteria.
        </div>
      )}
    </div>
  );
}
