import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { OutletCard } from "@/components/OutletCard";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter, SlidersHorizontal } from "lucide-react";
import type { Outlet } from "@shared/schema";

const categories = ["All", "Technology", "News", "Finance", "Wire Service"];

export default function Outlets() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: outlets = [], isLoading } = useQuery<Outlet[]>({
    queryKey: ["/api/outlets"],
  });

  const filteredOutlets = outlets.filter((o) => {
    const matchesCategory = selectedCategory === "All" || o.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      o.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">Media Outlets</h1>
        <p className="text-muted-foreground mt-2">
          Analyze coverage patterns across {outlets.length}+ news organizations
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <SearchBar 
          placeholder="Search outlets..."
          onSearch={setSearchQuery}
        />
        <Button variant="outline" data-testid="button-filters">
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
        <Button variant="outline" data-testid="button-sort">
          <SlidersHorizontal className="h-4 w-4 mr-2" />
          Sort
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Badge
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            className="cursor-pointer hover-elevate active-elevate-2"
            onClick={() => setSelectedCategory(category)}
            data-testid={`badge-category-${category.toLowerCase()}`}
          >
            {category}
          </Badge>
        ))}
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading outlets...</div>
      ) : filteredOutlets.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredOutlets.map((outlet) => (
            <OutletCard key={outlet.id} {...outlet} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          No outlets found matching your criteria.
        </div>
      )}
    </div>
  );
}
