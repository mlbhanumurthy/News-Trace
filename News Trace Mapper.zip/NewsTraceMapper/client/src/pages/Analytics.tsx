import { ActivityChart } from "@/components/ActivityChart";
import { TopicDistribution } from "@/components/TopicDistribution";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground mt-2">
          Deep insights into coverage trends and journalist behavior
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="trends" data-testid="tab-trends">Trends</TabsTrigger>
          <TabsTrigger value="comparison" data-testid="tab-comparison">Comparison</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <ActivityChart />
            <TopicDistribution />
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Most Active Outlet
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">Reuters</p>
                <p className="text-sm text-muted-foreground mt-1">1,523 articles/month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Fastest Growing Beat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">AI & Tech</p>
                <div className="flex items-center gap-1 text-chart-2 text-sm mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+34% this month</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Declining Coverage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">Sports</p>
                <div className="flex items-center gap-1 text-destructive text-sm mt-1">
                  <TrendingDown className="h-4 w-4" />
                  <span>-12% this month</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Trend Analysis Coming Soon</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Advanced trend analysis and predictive insights will be available here.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Outlet Comparison Coming Soon</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Compare coverage patterns and journalist distribution across outlets.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
