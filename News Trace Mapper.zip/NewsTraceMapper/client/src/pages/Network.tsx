import { NetworkGraph } from "@/components/NetworkGraph";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Share2 } from "lucide-react";

export default function Network() {
  const insights = [
    { label: "Total Connections", value: "1,247" },
    { label: "Clusters Detected", value: "8" },
    { label: "Avg. Connection Strength", value: "0.73" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Network Analysis</h1>
          <p className="text-muted-foreground mt-2">
            Visualize connections and relationships across the media ecosystem
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-share">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
          <Button data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {insights.map((insight) => (
          <Card key={insight.label}>
            <CardHeader className="pb-2">
              <p className="text-sm font-medium text-muted-foreground">
                {insight.label}
              </p>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold tracking-tight">{insight.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <NetworkGraph />

      <Card>
        <CardHeader>
          <CardTitle>Network Insights</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Key Influencers</h3>
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Sarah Chen (92)</Badge>
              <Badge variant="secondary">Michael Torres (88)</Badge>
              <Badge variant="secondary">Lisa Park (91)</Badge>
              <Badge variant="secondary">Jennifer Adams (94)</Badge>
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Trending Topics</h3>
            <div className="flex flex-wrap gap-2">
              <Badge>AI & Technology</Badge>
              <Badge>Climate Policy</Badge>
              <Badge>Economic Recovery</Badge>
              <Badge>Healthcare Reform</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
