# NewsTrace Design Guidelines

## Design Approach

**Selected Approach:** Hybrid System (Material Design + Linear-inspired Dark Aesthetics)
- **Rationale:** Data-heavy intelligence platform requiring robust component patterns (Material Design) combined with sophisticated dark UI aesthetics and modern visual polish (Linear/Observable inspiration)
- **Key References:** Linear's clean dark interfaces, Observable's data visualization clarity, GitHub's professional dark mode patterns
- **Core Principle:** Information density meets visual elegance - every pixel serves a purpose while maintaining visual hierarchy

## Typography System

**Font Stack:**
- Primary: 'Inter' for UI, data labels, and body text (weights: 400, 500, 600, 700)
- Monospace: 'JetBrains Mono' for journalist handles, URLs, metadata (weight: 400, 500)

**Hierarchy:**
- Hero/Dashboard Headers: text-4xl to text-5xl, font-bold, tracking-tight
- Section Headers: text-2xl to text-3xl, font-semibold
- Card/Component Titles: text-lg to text-xl, font-semibold
- Body/Data: text-sm to text-base, font-normal
- Metadata/Labels: text-xs to text-sm, font-medium, uppercase tracking for labels
- Monospace Data: text-sm, font-mono for technical identifiers

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16 for consistent rhythm
- Micro spacing: gap-2, p-2 for tight groups
- Standard spacing: gap-4, p-4, m-4 for component padding
- Section spacing: p-6, gap-6 for card internals
- Major spacing: p-8, gap-8, my-12 for page sections
- Hero/Feature spacing: py-16, gap-16 for landing sections

**Grid System:**
- Dashboard: 12-column grid with sidebar (fixed 64 collapsed/256 expanded) + main content area
- Data Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Network View: Full-width with collapsible side panels
- Journalist Profiles: 2-column layout (8-col content + 4-col metadata sidebar on lg+)

**Container Strategy:**
- Dashboard containers: max-w-screen-2xl for wide data displays
- Content containers: max-w-7xl for readable content
- Modal content: max-w-4xl for detail views

## Component Library

### Navigation
**Top Navigation Bar:**
- Fixed header (h-16) with backdrop blur effect
- Logo + search bar (takes 50% width on lg+) + user actions
- Persistent across all views

**Sidebar Navigation:**
- Collapsible (w-16 collapsed, w-64 expanded)
- Icon + label pattern, active state with accent indicator bar
- Sections: Dashboard, Journalists, Outlets, Network, Analytics, Settings

### Dashboard Components

**Stat Cards:**
- Compact cards (p-6) with icon, large number (text-3xl font-bold), label, and trend indicator
- 4-column grid on xl, 2-column on md, single on mobile
- Include micro sparkline charts where relevant

**Data Tables:**
- Sticky header row with sortable columns
- Alternating row treatment for readability
- Row hover states with subtle elevation change
- Action buttons (view, analyze) on row hover
- Pagination at bottom with items-per-page selector

**Network Graph Container:**
- Full-screen capable with zoom/pan controls
- Legend panel (floating, draggable, collapsible)
- Node interaction panel showing details on click
- Toolbar with filter controls, layout algorithms, export options

### Cards & Panels

**Journalist Profile Cards:**
- Image (48x48 avatar) + name + outlet + beat tags
- Stats row (articles count, influence score, activity timeline)
- Quick actions (view profile, track, add to list)
- Hover state with elevation and border treatment

**Outlet Cards:**
- Outlet logo/icon (64x64) + name + category badge
- Journalist count, article frequency, coverage distribution
- Mini bar chart showing topic distribution

**Analysis Panels:**
- Tabbed interface for different analysis views
- Charts occupy 60% width, insights/data 40%
- Export and share controls in panel header

### Forms & Inputs

**Search Bar:**
- Prominent (h-12) with icon prefix
- Multi-filter capability with tag chips showing active filters
- Autocomplete dropdown with entity type indicators (journalist/outlet/topic)
- Keyboard shortcuts displayed subtly

**Filter Panels:**
- Collapsible accordion sections for filter categories
- Checkbox groups, date range pickers, tag selectors
- Apply/Clear buttons, active filter count badge
- Sticky positioning when scrolling

### Overlays

**Modal Dialogs:**
- Journalist detail view: Full screen on mobile, max-w-4xl centered on desktop
- Network node detail: Sliding panel from right (w-96)
- Confirmation dialogs: Compact centered cards (max-w-md)

**Toast Notifications:**
- Positioned top-right, stacked with gap-2
- Auto-dismiss with progress indicator
- Action buttons for relevant notifications (undo, view details)

## Data Visualizations

**Network Graph:**
- Node sizing based on influence/article count
- Edge thickness representing connection strength
- Clustering algorithm with clear visual separation
- Interactive tooltips on hover with journalist/outlet info

**Charts & Graphs:**
- Line charts for trends over time (article frequency, topic evolution)
- Bar charts for comparisons (outlet coverage, journalist productivity)
- Donut charts for distribution (beat coverage, outlet shares)
- Heat maps for activity patterns (publication schedule, outlet coordination)

**Treatment:**
- Minimal grid lines, clear axis labels
- Data point hover states with detailed tooltips
- Smooth transitions when filtering/updating data
- Legend positioned strategically (top-right or bottom for horizontal charts)

## Animations

**Strategic Use Only:**
- Page transitions: Subtle fade-in for route changes (150ms)
- Network graph: Smooth force-directed layout settling
- Data updates: Numbers count-up animation on stat cards
- Hover states: Quick elevation/scale changes (100-150ms)
- **Avoid:** Excessive scroll animations, decorative effects, distracting micro-interactions

## Images

**Hero Section (Landing/Marketing Page if applicable):**
- Large hero image (h-[600px]) showing network graph visualization or journalist mapping interface
- Blurred background treatment with gradient overlay
- CTA buttons with backdrop-blur backgrounds

**Dashboard:**
- Journalist avatars (48x48 in cards, 96x96 in profiles, 128x128 in detail modals)
- Outlet logos (64x64 standard, 128x128 in headers)
- Placeholder states use initials or generic icons

**Empty States:**
- Illustrative graphics for "no data" scenarios
- Simple line art style maintaining dark theme consistency

## Accessibility

- Consistent focus indicators across all interactive elements
- ARIA labels for icon-only buttons and complex visualizations
- Keyboard navigation support (Tab, Enter, Escape, Arrow keys for graphs)
- Form inputs with visible labels and error states
- Sufficient contrast ratios maintained throughout dark theme